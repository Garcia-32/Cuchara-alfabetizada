/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_compra;
import Sistema.*;
import java.util.Scanner;
public class Main {

    
    public static void main(String[] args) {
       
          Scanner sc = new Scanner(System.in);
        Tienda tienda = new Tienda();

        System.out.print("Ingrese el número de clientes: ");
        int n = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        for (int i = 0; i < n; i++) {
            System.out.printf("\nCliente %d\n", i + 1);
            System.out.print("Nombre del cliente: ");
            String nombre = sc.nextLine();

            String tipoPantalon;
            while (true) {
                System.out.print("Tipo de pantalón (Deportivo, Casual, Elegante): ");
                tipoPantalon = sc.nextLine().trim();
                if (tipoPantalon.equalsIgnoreCase("Deportivo") ||
                    tipoPantalon.equalsIgnoreCase("Casual") ||
                    tipoPantalon.equalsIgnoreCase("Elegante")) {
                    break;
                } else {
                    System.out.println("Tipo inválido. Intente de nuevo.");
                }
            }

            System.out.print("Cantidad a comprar: ");
            int cantidad = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            Cliente cliente = new Cliente(nombre, tipoPantalon, cantidad);
            tienda.agregarCliente(cliente);
        }

        // Mostrar resumen final
        tienda.mostrarResumen();

        sc.close();
    }
}
