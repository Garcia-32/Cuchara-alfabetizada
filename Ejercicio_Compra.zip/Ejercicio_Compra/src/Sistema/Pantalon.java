/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

public class Pantalon {
 private String tipo;
    private double precioUnitario;

    // Constructor que asigna tipo y precio según el tipo
    public Pantalon(String tipo) {
        this.tipo = tipo;
        switch (tipo.toLowerCase()) {
            case "deportivo":
                this.precioUnitario = 90;
                break;
            case "casual":
                this.precioUnitario = 120;
                break;
            case "elegante":
                this.precioUnitario = 135;
                break;
            default:
                this.precioUnitario = 0;
                break;
        }
    }

    // Getter para el precio unitario
    public double getPrecioUnitario() {
        return precioUnitario;
    }

    // Getter para el tipo
    public String getTipo() {
        return tipo;
    }   
}


