/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.util.ArrayList;
public class Tienda {
    
    private ArrayList<Cliente> listaClientes;
    private double totalSubtotal;
    private double totalDescuento;
    private double totalFinal;

    // Constructor inicializa la lista de clientes
    public Tienda() {
        listaClientes = new ArrayList<>();
        totalSubtotal = 0;
        totalDescuento = 0;
        totalFinal = 0;
    }

    // Agrega un cliente a la lista y actualiza totales
    public void agregarCliente(Cliente cliente) {
        listaClientes.add(cliente);
        totalSubtotal += cliente.getSubtotal();
        totalDescuento += cliente.getDescuento();
        totalFinal += cliente.getTotal();
    }

    // Muestra el resumen de cada cliente y los totales generales
    public void mostrarResumen() {
        System.out.println("\nResumen de compras por cliente:");
        for (Cliente c : listaClientes) {
            System.out.printf("Cliente: %s\n", c.getNombre());
            System.out.printf("Tipo de Pantalón: %s\n", c.getTipoPantalon());
            System.out.printf("Cantidad: %d\n", c.getCantidad());
            System.out.printf("Subtotal: S/. %.2f\n", c.getSubtotal());
            System.out.printf("Descuento: S/. %.2f\n", c.getDescuento());
            System.out.printf("Total a pagar: S/. %.2f\n", c.getTotal());
            System.out.println("-----------------------------");
        }
        System.out.println("Totales generales de la tienda:");
        System.out.printf("Subtotal total: S/. %.2f\n", totalSubtotal);
        System.out.printf("Descuento total: S/. %.2f\n", totalDescuento);
        System.out.printf("Total final a pagar: S/. %.2f\n", totalFinal);
    }
}
