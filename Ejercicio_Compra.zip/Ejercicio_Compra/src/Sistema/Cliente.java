/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

public class Cliente {
    
    private String nombre;
    private Pantalon pantalon;
    private int cantidad;
    private double subtotal;
    private double descuento;
    private double total;

    // Constructor que recibe nombre, tipo de pantalon y cantidad
    public Cliente(String nombre, String tipoPantalon, int cantidad) {
        this.nombre = nombre;
        this.pantalon = new Pantalon(tipoPantalon);
        this.cantidad = cantidad;
        calcularSubtotal();
        calcularDescuento();
        calcularTotal();
    }

    // Calcula el subtotal sin descuento
    private void calcularSubtotal() {
        subtotal = pantalon.getPrecioUnitario() * cantidad;
    }

    // Calcula el descuento según la cantidad comprada
    private void calcularDescuento() {
        if (cantidad >= 1 && cantidad <= 5) {
            descuento = subtotal * 0.05;
        } else if (cantidad >= 6 && cantidad <= 8) {
            descuento = subtotal * 0.09;
        } else if (cantidad >= 9) {
            descuento = subtotal * 0.14;
        } else {
            descuento = 0;
        }
    }

    // Calcula el total a pagar después del descuento
    private void calcularTotal() {
        total = subtotal - descuento;
    }

    // Getters para mostrar resultados
    public String getNombre() {
        return nombre;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public double getTotal() {
        return total;
    }

    public String getTipoPantalon() {
        return pantalon.getTipo();
    }

    public int getCantidad() {
        return cantidad;
    }
}