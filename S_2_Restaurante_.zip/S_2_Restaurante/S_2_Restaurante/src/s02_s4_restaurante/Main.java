/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package s02_s4_restaurante;

import Librero.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
  
//declara lista e inicializa
    static List<plato> Carta1 = new ArrayList<plato>(Arrays.asList(
            new plato("PLATO 02", 43.56),
            new plato("PLATO 11", 43.45),
            new plato("PLATO 13", 12.65),
            new plato("PLATO 18", 43.23),
            new plato("PLATO 20", 60.23),
            new plato("PLATO 20", 60.23)));

    static Scanner consola = new Scanner(System.in);

private static comenzal RegistrarComenzal() {
        comenzal objComenzal = new comenzal();
        System.out.println("Ingrese datos del comenzal: ");
        System.out.println("Ingrese DNI: ");
        objComenzal.setDNI(consola.nextInt());

        System.out.println("Ingrese nombres: ");
        objComenzal.setNombre(consola.next());

        System.out.println("Ingrese apellidos: ");
        objComenzal.setApellidos(consola.next());

        return objComenzal;
    }
 private static List<plato> SeleccionarPlatos(){
        int nro = 0;
        List<plato> listaPlatos = new ArrayList<plato>();
        
        while(true){
            int con = 1;
            System.out.println("Carta de platos\n----------------- ");
            
            for (plato p:Carta1){
                System.out.println(con + ".-" + p.getNombre() + "\t"+ p.getPrecio()); 
                        con ++;
                
            }
           System.out.println("Elija el numero de plato\n(0) para salir ==>");
           nro = consola.nextInt();
           if (nro == 0){
               break;
            }
            else
            if(nro< Carta1.size()){
               listaPlatos.add(Carta1.get(nro-1));
                    
            }         
            }
        return listaPlatos;
 }
 
public static void main (String[] args){
               System.out.println("Ingrese el numero de pedido: " );
               int numero = consola.nextInt();
               System.out.println("Ingrese el numero de mesa: " );
               int mesa = consola.nextInt();
               comenzal Comenzal = RegistrarComenzal();
               List<plato> listaplatos = SeleccionarPlatos();
               pedido pedidoNuevo = new pedido(numero, mesa);
               pedidoNuevo.RegistrarPedido(Comenzal, listaplatos);
                  
           }
}

