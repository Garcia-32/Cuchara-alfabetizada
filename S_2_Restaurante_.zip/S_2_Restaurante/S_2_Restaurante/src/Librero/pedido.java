/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Librero;
import java.util.Date;
import java.util.List;

public class pedido {
    private int numero;
    private Date fecha;
    private int mesa;
    private List<plato> platos;
    private comenzal comenzal;
    
    public pedido(){
        
    }
    public pedido(int numero, int mesa){
        this.numero = numero;
        this.mesa = mesa;
        this.fecha = new Date();
        
    }
    public void RegistrarPedido (comenzal comenzal, List <plato> platos){
        this.platos = platos;
        this.comenzal = comenzal;
        System.out.println("\n-----------------------------");
        System.out.println("REGISTRAR PEDIDO");
        System.out.println("-----------------------------");
        System.out.println("Número: " + this.numero);
        System.out.println("Fecha: "+ this.fecha.toString());
        System.out.println("Mesa: " + this.mesa);
        System.out.println("Comenzal: " + this.comenzal.getDNI ()+ " - "
                            + this.comenzal.getNombre()+ " - " 
                            + this.comenzal.getApellidos ()+ " - ");
        System.out.println("PLATOS\n-------------------------");
        
        for (plato p : this.platos){
            System.out.println(p.getNombre()+ " - " + p.getPrecio());
        }
    }
    
}
