/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libreria;


public class comenzal {

   private int DNI;
   private String Nombre;
   private String Apellidos;

    public comenzal(){
        
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }
    
    public void agregar(){
        System.out.println("Agregando comenzal!!!" );
    }
    public void modificar(int DNI, String Nombre, String Apellido){
        System.out.println("Modificando comenzal" );
    }

    @Override
    public String toString() {
        return "Nombres: " + this.Nombre + "\nApellidos: " + this.Apellidos + "\nDNI: " + this.DNI;
    }
    
}
