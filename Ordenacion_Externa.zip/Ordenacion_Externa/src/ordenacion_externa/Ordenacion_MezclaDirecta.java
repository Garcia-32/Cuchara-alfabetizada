/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenacion_externa;
import java.io.*;
import java.util.*;

public class Ordenacion_MezclaDirecta {
    
   
    public static void main(String[] args) {
        int[] arreglo = {2,5,6,7,3,4,5,6,9};
        int[] auxiliar = new int[arreglo.length];
        ordenacion_MezclaDirecta(arreglo, auxiliar, 0, arreglo.length -1);
        System.out.println("Arreglo Ordenado: ");
        for (int i = 0; i < arreglo.length; i++){
            System.out.println(arreglo[i] + "");
        }
    public static void ordenacion_MezclaDirecta(int[] arreglo, int[] auxiliar), int izquierda, int derecha){
        if (izquierda < derecha){
            int medio = (izquierda + derecha)/2;
            
        }
        }    
    }
    
}
