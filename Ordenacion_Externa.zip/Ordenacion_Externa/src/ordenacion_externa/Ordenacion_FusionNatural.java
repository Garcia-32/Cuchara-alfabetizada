/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ordenacion_externa;
import java.io.*;
import java.util.*;

public class Ordenacion_FusionNatural {
   public static void ordenarFusion(String inputFile1, String inputFile2, String outputFile)throws IOException{
       File file1 = new File(inputFile1);
       File file2 = new File(inputFile2);
       Scanner scanner1 = new Scanner(file1);
       Scanner scanner2 = new Scanner(file2);
       
       List<Integer> numbers = new ArrayList<>();
       
       while(scanner1.hasNextInt()){
           numbers.add(scanner1.nextInt());
       }
       
       while(scanner2.hasNextInt()){
           numbers.add(scanner2.nextInt());
       }
       Collections.sort(numbers);
       
       FileWriter writer = new FileWriter(outputFile);
       
       for (Integer number : numbers){
           writer.write(number + "\n");
       }
       
       writer.close();
       scanner1.close();
       scanner2.close();
   } 
   public static void main(String[] args) throws IOException{
       ordenarFusion("input1.txt", "input2.txt", "ouypuy.txt");
   }
}
